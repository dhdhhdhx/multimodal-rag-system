"""
Audio transcription using Whisper.
"""
import logging
import os
import subprocess
import tempfile
import unicodedata
from pathlib import Path

import imageio_ffmpeg
import numpy as np
import whisper

logger = logging.getLogger(__name__)

SIMPLIFIED_CHINESE_PROMPT = "以下内容是中文语音，请输出简体中文，不要翻译，不要补充说明。"
TRADITIONAL_HINT_CHARS = set(
    "萬與專東絲兩嚴喪豐為麗舉麼義烏樂習鄉書買亂乾爭於虧雲亞產親億僅從倉儀們價眾優會傘偉傳傷倫偽體餘來侶俠俁係俔倀倆儉償儲兒剋黨冊寫軍農塊幣岡凍凱劃劉則剛創刪別剎劑剮剴劏剷剿劍劌劇勁勞勢勛勝區協單賣盧衛卻厭厲壓壘壞壟壢壩壇壯聲壺壽夠夢奪奮奧婦姍娛媧嫗學寧寶實審寫寬對尋導將專屆屍屜屢層嶄嶺嶼巔幣幹庫廁廂廄廈廚廝廟廠廣張彈強彌彎彙彞彥徑從徠復徵德憂戶撲撐撓撥擇擊擋據擠擴擺擾攝攜數斂斃時晉曉暈暢曆曇會機殺條來棄樓標樣樞樹橋檔檢欄歡歲歷歸歐殘殞殤殲殺氣漢湧灣濕濟濤濫灣燈營燦爐爭爺爾牆牽犧狀獨獄獅獎獲獸瑪環璣產畝疇療瘋瘍瘧瘡瘺盜盞監盤眾睜瞞礙禮禍禦稅穀穩窩竄競筆築範簽簾簡糧糾紀紂約紅紋納紐純級紛紙紮細紳紹紺終組經綁絆給絢統絲絕結綠維綱網緊緋緣編線練縣縱縫總績繫繼纏缽罈羅羈聖聞聯聰聲聳肅脅脈腦臉與艙艦艱藝節芻苧茲荊莊華萬萊著葦蕭薩藍藝虛虜蟲蠟衛衝補裝裡製複襲覺覽觀觸計訂訃訊訓訖記訛訝訟訣訪設許訴診詞詐詔評詛識詠詡試詩詫詬詭詢詮詰話該詳詵誇誌認誑誒語誠誤說誰課誶誹調諂談請諍諏諒論諗諛諜諞諢諤諦諧諫諭諮諱諳諶諷諸諺諾謀謁謂謄謅謊謎謐謔謙講謝謠謨謫謬謹證譎譏識譚譜譯議譴護讚讜豐豔財貢貝貞負貢財責賢敗賬貨質販貪貫貳貼貴貸貿賀資賈賊賑賓賕賚賜賞賠賢賦賬賭賴贈贊趕趙趨躍車軋軍軌軒軔軛軟転軸軼較輅載輊輒輕輝輩輪輯輸轄轅轍辦辭邊邏郵鄉鄧鄭醜醫釋鉅鋪鋒鋼錄錢錦鍋鍾鎖鏡鐘鐵鑄鑑長門閃閉開閑間閘閣閱闊隊陽陰陣陳陸際險難雜雞離霧靈靜響頁頂頃項順須頊頌預頑頓頗領頡頤頰題顏額顛類顧顫風飛飢飯飲飼飽餅餓館饅饞馬馭馮馱駐駛駝駭驗驅驚體髮鬥鬧魘魚鮮鯉鯊鯨鰓鱷鳥鳳鳴鴉鴻鴿鵝鵬麗麥黃黨點黴齊齋齒齡龍龐龜"
)


class AudioTranscriber:
    def __init__(self, model_size: str = "base"):
        logger.info("Loading Whisper model: %s", model_size)
        self.ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
        self.whisper_cache_dir = str(Path(__file__).resolve().parent.parent / ".model-cache" / "whisper")
        os.makedirs(self.whisper_cache_dir, exist_ok=True)

        ffmpeg_dir = os.path.dirname(self.ffmpeg_exe)
        path_items = os.environ.get("PATH", "").split(os.pathsep)
        if ffmpeg_dir not in path_items:
            os.environ["PATH"] = ffmpeg_dir + os.pathsep + os.environ.get("PATH", "")

        logger.info("Using ffmpeg from imageio-ffmpeg: %s", self.ffmpeg_exe)
        self.model = whisper.load_model(model_size, download_root=self.whisper_cache_dir)
        logger.info("Whisper model loaded")

    def _is_mostly_chinese(self, text: str) -> bool:
        if not text:
            return False
        chinese_chars = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
        visible_chars = sum(1 for ch in text if not ch.isspace())
        if visible_chars == 0:
            return False
        return chinese_chars / visible_chars >= 0.2

    def _traditional_ratio(self, text: str) -> float:
        chinese_chars = [ch for ch in text if "\u4e00" <= ch <= "\u9fff"]
        if not chinese_chars:
            return 0.0
        traditional_hits = sum(1 for ch in chinese_chars if ch in TRADITIONAL_HINT_CHARS)
        return traditional_hits / len(chinese_chars)

    def _looks_like_prompt_leakage(self, text: str) -> bool:
        lowered = text.lower()
        return "不要翻译" in text or "简体中文" in text or "output simplified chinese" in lowered

    def _guess_suffix(self, filename: str | None) -> str:
        if filename and "." in filename:
            suffix = filename[filename.rfind("."):].strip()
            if suffix:
                return suffix
        return ".mp3"

    def _load_audio(self, file_path: str, sample_rate: int = 16000) -> np.ndarray:
        cmd = [
            self.ffmpeg_exe,
            "-nostdin",
            "-threads", "0",
            "-i", file_path,
            "-f", "s16le",
            "-ac", "1",
            "-acodec", "pcm_s16le",
            "-ar", str(sample_rate),
            "-"
        ]
        try:
            out = subprocess.run(cmd, capture_output=True, check=True).stdout
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr.decode(errors="ignore") if exc.stderr else ""
            raise RuntimeError(f"Failed to decode audio via ffmpeg: {stderr}") from exc

        return np.frombuffer(out, np.int16).flatten().astype(np.float32) / 32768.0

    def _transcribe_once(
        self,
        audio_array: np.ndarray,
        language: str | None = None,
        initial_prompt: str | None = None,
    ) -> dict:
        options = {
            "fp16": False,
            "verbose": False,
            "temperature": 0,
            "condition_on_previous_text": False,
            "task": "transcribe",
        }
        if language:
            options["language"] = language
        if initial_prompt:
            options["initial_prompt"] = initial_prompt
        return self.model.transcribe(audio_array, **options)

    def _normalize_transcript_text(self, text: str) -> str:
        normalized = unicodedata.normalize("NFKC", text or "")
        normalized = normalized.replace("\r\n", "\n").replace("\r", "\n")
        normalized = "\n".join(line.strip() for line in normalized.split("\n"))
        normalized = "\n".join(line for line in normalized.split("\n") if line)
        return normalized.strip()

    def _candidate_score(self, result: dict, prefer_simplified_chinese: bool) -> float:
        text = self._normalize_transcript_text(result.get("text", ""))
        if not text:
            return float("-inf")

        language = (result.get("language") or "").lower()
        score = min(len(text), 4000) / 200.0

        if self._is_mostly_chinese(text):
            score += 4.0
        if language.startswith("zh"):
            score += 2.0
        if prefer_simplified_chinese:
            score -= self._traditional_ratio(text) * 10.0
        if self._looks_like_prompt_leakage(text):
            score -= 20.0
        return score

    def transcribe(
        self,
        audio_bytes: bytes,
        filename: str | None = None,
        preferred_language: str | None = None,
    ) -> dict:
        with tempfile.NamedTemporaryFile(delete=False, suffix=self._guess_suffix(filename)) as tmp_file:
            tmp_file.write(audio_bytes)
            tmp_path = tmp_file.name

        try:
            audio_array = self._load_audio(tmp_path)
            candidates: list[dict] = []

            auto_result = self._transcribe_once(audio_array)
            candidates.append(auto_result)

            if preferred_language:
                prompt = SIMPLIFIED_CHINESE_PROMPT if preferred_language == "zh" else None
                candidates.append(self._transcribe_once(audio_array, language=preferred_language, initial_prompt=prompt))
            else:
                candidates.append(
                    self._transcribe_once(
                        audio_array,
                        language="zh",
                        initial_prompt=SIMPLIFIED_CHINESE_PROMPT,
                    )
                )

            prefer_simplified = preferred_language == "zh" or any(
                (candidate.get("language") or "").lower().startswith("zh")
                or self._is_mostly_chinese(candidate.get("text", ""))
                for candidate in candidates
            )

            best = max(candidates, key=lambda item: self._candidate_score(item, prefer_simplified))
            text = self._normalize_transcript_text(best.get("text", ""))
            language = best.get("language", "unknown")

            return {
                "text": text,
                "language": language,
            }
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
