"""
Image Embedding using CLIP
"""
import io
import logging

import numpy as np
import torch
from PIL import Image
from transformers import CLIPModel, CLIPProcessor

logger = logging.getLogger(__name__)

class ImageEmbedder:
    LABEL_MAPPINGS = [
        ("person", "人物"),
        ("people", "多人场景"),
        ("face", "人像"),
        ("presentation slide", "演示文稿"),
        ("chart", "图表"),
        ("document page", "文档页面"),
        ("text document", "文本文档"),
        ("computer screen", "电脑屏幕"),
        ("laptop", "笔记本电脑"),
        ("mobile phone", "手机"),
        ("electronics", "电子设备"),
        ("robot", "机器人"),
        ("mechanical device", "机械装置"),
        ("toy", "玩具"),
        ("car", "汽车"),
        ("building", "建筑"),
        ("indoor scene", "室内场景"),
        ("outdoor scene", "室外场景"),
        ("nature landscape", "自然风景"),
        ("animal", "动物"),
        ("food", "食物")
    ]

    def __init__(self, model_name='openai/clip-vit-base-patch32'):
        """
        Initialize CLIP image embedder
        
        Args:
            model_name: HuggingFace CLIP model name
        """
        logger.info(f"Loading CLIP model: {model_name}")
        self.model = CLIPModel.from_pretrained(model_name)
        self.processor = CLIPProcessor.from_pretrained(model_name)
        self.dimension = 512  # CLIP image features dimension
        logger.info(f"CLIP model loaded, dimension: {self.dimension}")
    
    def embed(self, image_bytes: bytes) -> np.ndarray:
        """
        Embed image into vector
        """
        # Load image from bytes
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        
        # Process and embed
        inputs = self.processor(images=image, return_tensors="pt")
        with torch.no_grad():
            image_features = self.model.get_image_features(**inputs)
        
        # Convert to numpy and normalize, ensure 1D
        embedding = image_features[0].cpu().detach().numpy().flatten()
        embedding = embedding / np.linalg.norm(embedding)  # L2 normalize

        return embedding
    
    def describe(self, image_bytes: bytes, labels: list = None) -> list:
        """
        Identify top labels for the image using Zero-Shot classification
        """
        if labels is None:
            labels = self.LABEL_MAPPINGS

        english_labels = [item[0] if isinstance(item, tuple) else item for item in labels]
        label_map = {
            item[0]: item[1] if isinstance(item, tuple) else item
            for item in labels
        }

        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        
        inputs = self.processor(text=english_labels, images=image, return_tensors="pt", padding=True)
        with torch.no_grad():
            outputs = self.model(**inputs)
            
        logits_per_image = outputs.logits_per_image
        probs = logits_per_image.softmax(dim=1).cpu().numpy()[0]
        
        # Sort by probability
        label_probs = sorted(zip(english_labels, probs), key=lambda x: x[1], reverse=True)
        
        top_tags = []
        for index, (label, prob) in enumerate(label_probs[:5]):
            if index == 0 or prob > 0.12:
                chinese_label = label_map.get(label, label)
                if chinese_label not in top_tags:
                    top_tags.append(chinese_label)

        return top_tags
