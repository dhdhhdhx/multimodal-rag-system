"""
Video processing with keyframe extraction and transcript-aware summaries.
"""
import logging
import os
import tempfile
from io import BytesIO

import cv2
import numpy as np
from PIL import Image

from .audio_transcriber import AudioTranscriber
from .image_embedder import ImageEmbedder

logger = logging.getLogger(__name__)


class VideoProcessor:
    def __init__(self, frame_interval: int = 30):
        logger.info("Initializing video processor (interval: %s)", frame_interval)
        self.frame_interval = frame_interval
        self.image_embedder = ImageEmbedder()
        self.audio_transcriber = AudioTranscriber()
        logger.info("Video processor ready")

    def extract_keyframes(self, video_path: str, max_frames: int = 10):
        cap = cv2.VideoCapture(video_path)
        frames = []
        frame_count = 0

        while cap.isOpened() and len(frames) < max_frames:
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % self.frame_interval == 0:
                frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            frame_count += 1

        cap.release()
        logger.info("Extracted %s keyframes from video", len(frames))
        return frames

    def _build_summary(self, tags: list[str], transcript: str) -> str:
        parts = []
        if tags:
            parts.append("Visual tags: " + ", ".join(tags[:6]))
        if transcript:
            transcript_preview = transcript[:240]
            if len(transcript) > 240:
                transcript_preview += "..."
            parts.append("Transcript: " + transcript_preview)
        if not parts:
            return "No clear visual or spoken content could be extracted."
        return "\n".join(parts)

    def embed(self, video_bytes: bytes, filename: str | None = None) -> dict:
        suffix = ".mp4"
        if filename and "." in filename:
            suffix = filename[filename.rfind("."):]

        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
            tmp_file.write(video_bytes)
            tmp_path = tmp_file.name

        try:
            frames = self.extract_keyframes(tmp_path)
            transcript_result = self.audio_transcriber.transcribe(video_bytes, filename=filename)
            transcript = transcript_result.get("text", "")

            if not frames:
                return {
                    "embedding": np.zeros(512, dtype=np.float32),
                    "tags": [],
                    "transcript": transcript,
                    "summary": self._build_summary([], transcript),
                }

            embeddings = []
            all_tags = []
            for frame in frames:
                image = Image.fromarray(frame)
                image_bytes = BytesIO()
                image.save(image_bytes, format="PNG")
                payload = image_bytes.getvalue()

                embeddings.append(self.image_embedder.embed(payload))
                all_tags.extend(self.image_embedder.describe(payload))

            unique_tags = list(dict.fromkeys(tag for tag in all_tags if tag))
            avg_embedding = np.mean([np.asarray(embedding).flatten() for embedding in embeddings], axis=0)
            norm = np.linalg.norm(avg_embedding)
            if norm > 0:
                avg_embedding = avg_embedding / norm

            return {
                "embedding": avg_embedding,
                "tags": unique_tags,
                "transcript": transcript,
                "summary": self._build_summary(unique_tags, transcript),
            }
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
