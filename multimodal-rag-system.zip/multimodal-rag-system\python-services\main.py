import os

BASE_DIR = os.path.dirname(__file__)
CACHE_ROOT = os.path.join(BASE_DIR, ".model-cache")
HF_CACHE_DIR = os.path.join(CACHE_ROOT, "huggingface")

# Force CPU-only mode to prevent hangs during CUDA initialization
os.environ["CUDA_VISIBLE_DEVICES"] = ""
# Use a HuggingFace mirror by default to avoid timeout issues in mainland network environments.
os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
os.environ.setdefault("HF_HOME", HF_CACHE_DIR)
os.environ.setdefault("TRANSFORMERS_CACHE", HF_CACHE_DIR)
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", HF_CACHE_DIR)
os.environ.setdefault("XDG_CACHE_HOME", CACHE_ROOT)

os.makedirs(HF_CACHE_DIR, exist_ok=True)

"""
Multimodal Embedding Service
FastAPI service for text, image, audio, and video embeddings
"""
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import logging

# Import model handlers
from models.text_embedder import TextEmbedder
from models.image_embedder import ImageEmbedder
from models.audio_transcriber import AudioTranscriber
from models.video_processor import VideoProcessor
from utils.vector_aligner import VectorAligner

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Multimodal Embedding Service",
    description="AI service for embedding text, images, audio, and video",
    version="1.0.0"
)

# Initialize models (lazy loading on first request)
text_embedder: Optional[TextEmbedder] = None
image_embedder: Optional[ImageEmbedder] = None
audio_transcriber: Optional[AudioTranscriber] = None
video_processor: Optional[VideoProcessor] = None
vector_aligner: Optional[VectorAligner] = None

# Request/Response models
class TextEmbedRequest(BaseModel):
    text: str

class EmbeddingResponse(BaseModel):
    embedding: List[float]
    dimension: int
    aligned: bool = False
    tags: Optional[List[str]] = None
    text: Optional[str] = None
    summary: Optional[str] = None

class TranscriptionResponse(BaseModel):
    text: str
    language: Optional[str] = None

@app.on_event("startup")
async def startup_event():
    """Initialize models on startup (Deferred to first request for performance)"""
    logger.info("Service starting in Lazy-Loading mode...")
    print("DEBUG: Service starting in Lazy-Loading mode...")
    # All models are now lazy-loaded in their respective endpoints
    logger.info("Service ready!")

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "service": "Multimodal Embedding Service",
        "status": "running",
        "models": {
            "text": text_embedder is not None,
            "image": image_embedder is not None,
            "audio": audio_transcriber is not None,
            "video": video_processor is not None
        }
    }

@app.post("/embed/text", response_model=EmbeddingResponse)
async def embed_text(request: TextEmbedRequest, align: bool = True):
    """
    Embed text using sentence-transformers
    
    Args:
        request: Text to embed
        align: Whether to align to 256 dimensions
    
    Returns:
        Embedding vector
    """
    global text_embedder, vector_aligner
    
    # Lazy load text embedder
    if text_embedder is None:
        logger.info("Loading text embedder...")
        try:
            text_embedder = TextEmbedder()
            logger.info("✓ Text embedder loaded")
        except Exception as e:
            raise HTTPException(status_code=503, detail=f"Failed to load text embedder: {e}")
            
    # Lazy load vector aligner
    if vector_aligner is None:
        logger.info("Initializing vector aligner...")
        try:
            vector_aligner = VectorAligner(target_dim=384)
            logger.info("✓ Vector aligner initialized")
        except Exception as e:
            # Not critical, can continue without alignment
            logger.warning(f"Failed to initialize vector aligner: {e}")
    
    try:
        embedding = text_embedder.embed(request.text)
        
        if align and vector_aligner:
            embedding = vector_aligner.align(embedding, modality='text')
            return EmbeddingResponse(
                embedding=embedding.tolist(),
                dimension=384,
                aligned=True
            )
        
        return EmbeddingResponse(
            embedding=embedding.tolist(),
            dimension=len(embedding),
            aligned=False
        )
    except Exception as e:
        logger.error(f"Text embedding failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/embed/image", response_model=EmbeddingResponse)
async def embed_image(file: UploadFile = File(...), align: bool = True):
    """
    Embed image using CLIP
    
    Args:
        file: Image file
        align: Whether to align to 256 dimensions
    
    Returns:
        Embedding vector
    """
    global image_embedder, vector_aligner
    
    # Lazy load image embedder
    if image_embedder is None:
        logger.info("Loading image embedder...")
        try:
            image_embedder = ImageEmbedder()
            logger.info("✓ Image embedder loaded")
        except Exception as e:
            raise HTTPException(status_code=503, detail=f"Failed to load image embedder: {e}")
    
    try:
        contents = await file.read()
        embedding = image_embedder.embed(contents)
        
        tags = image_embedder.describe(contents)
        summary = None
        if tags:
            summary = "图片内容要点：" + "、".join(tags[:6])
        if align and vector_aligner:
            embedding = vector_aligner.align(embedding, modality='image')
            return EmbeddingResponse(
                embedding=embedding.tolist(),
                dimension=384,
                aligned=True,
                tags=tags,
                summary=summary
            )
        
        return EmbeddingResponse(
            embedding=embedding.tolist(),
            dimension=len(embedding),
            aligned=False,
            tags=tags,
            summary=summary
        )
    except Exception as e:
        logger.error(f"Image embedding failed with error: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/transcribe/audio", response_model=TranscriptionResponse)
async def transcribe_audio(file: UploadFile = File(...), language: Optional[str] = Form(default=None)):
    """
    Transcribe audio using Whisper
    
    Args:
        file: Audio file (mp3, wav, m4a)
    
    Returns:
        Transcribed text
    """
    global audio_transcriber
    
    # Lazy load audio transcriber
    if audio_transcriber is None:
        logger.info("Loading audio transcriber...")
        try:
            audio_transcriber = AudioTranscriber()
            logger.info("✓ Audio transcriber loaded")
        except Exception as e:
            raise HTTPException(status_code=503, detail=f"Failed to load audio transcriber: {e}")
    
    try:
        contents = await file.read()
        result = audio_transcriber.transcribe(
            contents,
            filename=file.filename,
            preferred_language=language
        )
        
        return TranscriptionResponse(
            text=result['text'],
            language=result.get('language')
        )
    except Exception as e:
        logger.error(f"Audio transcription failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/embed/audio", response_model=EmbeddingResponse)
async def embed_audio(file: UploadFile = File(...), align: bool = True):
    """
    Embed audio by transcribing to text then embedding
    
    Args:
        file: Audio file
        align: Whether to align to 256 dimensions
    
    Returns:
        Embedding vector
    """
    # First transcribe
    transcription = await transcribe_audio(file)
    
    response = await embed_text(TextEmbedRequest(text=transcription.text), align=align)
    response.text = transcription.text
    response.summary = f"音频转写：{transcription.text[:240]}{'...' if len(transcription.text) > 240 else ''}"
    return response

@app.post("/embed/video", response_model=EmbeddingResponse)
async def embed_video(file: UploadFile = File(...), align: bool = True):
    """
    Embed video by extracting keyframes and using CLIP
    
    Args:
        file: Video file
        align: Whether to align to 256 dimensions
    
    Returns:
        Averaged embedding vector from keyframes
    """
    global video_processor, vector_aligner
    
    # Lazy load video processor
    if video_processor is None:
        logger.info("Loading video processor...")
        try:
            video_processor = VideoProcessor()
            logger.info("✓ Video processor loaded")
        except Exception as e:
            raise HTTPException(status_code=503, detail=f"Failed to load video processor: {e}")
    
    try:
        contents = await file.read()
        result = video_processor.embed(contents, filename=file.filename)
        embedding = result['embedding']
        tags = result.get('tags')
        transcript = result.get('transcript')
        summary = result.get('summary')
        
        if align and vector_aligner:
            embedding = vector_aligner.align(embedding, modality='image')
            return EmbeddingResponse(
                embedding=embedding.tolist(),
                dimension=384,
                aligned=True,
                tags=tags,
                text=transcript,
                summary=summary
            )
        
        return EmbeddingResponse(
            embedding=embedding.tolist(),
            dimension=len(embedding),
            aligned=False,
            tags=tags,
            text=transcript,
            summary=summary
        )
    except Exception as e:
        logger.error(f"Video embedding failed with error: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
