"""
Text Embedding using sentence-transformers
"""
from sentence_transformers import SentenceTransformer
import numpy as np
import logging

logger = logging.getLogger(__name__)

class TextEmbedder:
    def __init__(self, model_name='sentence-transformers/all-MiniLM-L6-v2'):
        """
        Initialize text embedder
        
        Args:
            model_name: HuggingFace model name
        """
        logger.info(f"Loading text model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.dimension = self.model.get_sentence_embedding_dimension()
        logger.info(f"Text model loaded, dimension: {self.dimension}")
    
    def embed(self, text: str) -> np.ndarray:
        """
        Embed text into vector
        
        Args:
            text: Input text
        
        Returns:
            Embedding vector (384-dim)
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding
    
    def embed_batch(self, texts: list) -> np.ndarray:
        """
        Embed multiple texts
        
        Args:
            texts: List of texts
        
        Returns:
            Array of embeddings
        """
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return embeddings
