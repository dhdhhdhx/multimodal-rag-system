# Multimodal Embedding Service

Python FastAPI service for embedding text, images, audio, and video.

## Features

- 📝 **Text Embedding**: sentence-transformers/all-MiniLM-L6-v2 (384-dim)
- 🖼️ **Image Embedding**: CLIP vit-base-patch32 (512-dim)
- 🎵 **Audio Transcription**: Whisper (base model)
- 🎬 **Video Embedding**: Keyframe extraction + CLIP
- 🔄 **Vector Alignment**: PCA to 256-dim unified space

## Installation

```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate  # Windows
# source venv/bin/activate  # Linux/Mac

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Start Service

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### API Endpoints

#### Health Check
```bash
GET http://localhost:8000/
```

#### Embed Text
```bash
POST http://localhost:8000/embed/text
Body: {"text": "Hello world"}
```

#### Embed Image
```bash
POST http://localhost:8000/embed/image
Body: multipart/form-data with "file" field
```

#### Transcribe Audio
```bash
POST http://localhost:8000/transcribe/audio
Body: multipart/form-data with "file" field
```

#### Embed Audio (transcribe + embed)
```bash
POST http://localhost:8000/embed/audio
Body: multipart/form-data with "file" field
```

#### Embed Video
```bash
POST http://localhost:8000/embed/video
Body: multipart/form-data with "file" field
```

## Models

All models are downloaded automatically on first use:
- Text: ~90MB
- CLIP: ~600MB
- Whisper (base): ~140MB

Total: ~830MB

## Response Format

```json
{
  "embedding": [0.12, -0.34, 0.56, ...],
  "dimension": 256,
  "aligned": true
}
```

## Notes

- First request to each endpoint will be slower (model loading)
- Models are cached in memory after loading
- Use `?align=false` to get original dimensions
