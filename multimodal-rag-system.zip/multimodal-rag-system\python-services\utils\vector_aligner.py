"""
Vector Alignment using PCA
Aligns different modality embeddings to a unified dimension
"""
from sklearn.decomposition import PCA
import numpy as np
import logging
import pickle
import os

logger = logging.getLogger(__name__)

class VectorAligner:
    def __init__(self, target_dim=256):
        """
        Initialize vector aligner
        
        Args:
            target_dim: Target dimension for all embeddings
        """
        self.target_dim = target_dim
        self.pcas = {}
        logger.info(f"Vector aligner initialized (target dimension: {target_dim})")
    
    def fit_and_save(self, embeddings: np.ndarray, modality: str, save_path: str = None):
        """
        Fit PCA for a modality and save
        
        Args:
            embeddings: Training embeddings (N x D)
            modality: Modality name ('text', 'image', etc.)
            save_path: Path to save PCA model
        """
        original_dim = embeddings.shape[1]
        logger.info(f"Fitting PCA for {modality}: {original_dim} → {self.target_dim}")
        
        pca = PCA(n_components=self.target_dim)
        pca.fit(embeddings)
        
        self.pcas[modality] = pca
        
        # Save if path provided
        if save_path:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'wb') as f:
                pickle.dump(pca, f)
            logger.info(f"PCA model saved to {save_path}")
        
        explained_var = sum(pca.explained_variance_ratio_)
        logger.info(f"PCA fitted for {modality}, explained variance: {explained_var:.2%}")
    
    def load_pca(self, modality: str, load_path: str):
        """Load pre-trained PCA model"""
        with open(load_path, 'rb') as f:
            self.pcas[modality] = pickle.load(f)
        logger.info(f"PCA model loaded for {modality} from {load_path}")
    
    def align(self, embedding: np.ndarray, modality: str) -> np.ndarray:
        """
        Align embedding to target dimension
        
        Args:
            embedding: Input embedding vector
            modality: Modality name
        
        Returns:
            Aligned embedding (target_dim)
        """
        embedding = np.array(embedding).reshape(1, -1)
        original_dim = embedding.shape[1]
        
        # If already at target dimension, return as-is
        if original_dim == self.target_dim:
            return embedding[0]
        
        # If PCA not fitted for this modality, fit on-the-fly (simple truncation)
        if modality not in self.pcas:
            logger.warning(f"PCA not fitted for {modality}, using simple projection")
            if original_dim > self.target_dim:
                # Truncate
                return embedding[0][:self.target_dim]
            else:
                # Pad with zeros
                return np.pad(embedding[0], (0, self.target_dim - original_dim))
        
        # Use fitted PCA
        aligned = self.pcas[modality].transform(embedding)
        return aligned[0]
